package com.project.mypetcareapp;

import android.annotation.SuppressLint;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;


public class Fragment2 extends Fragment {
    private EditText DewormingDate, DewormingDueDate;
    private DatabaseReference databaseReference;
    private Button saveDeworm;

    @SuppressLint("MissingInflatedId")
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_2, container, false);

        DewormingDate = view.findViewById(R.id.editTextDate3);
        DewormingDueDate = view.findViewById(R.id.editText);
        saveDeworm = view.findViewById(R.id.dewormsave);

        databaseReference = FirebaseDatabase.getInstance().getReference().child("Deworming");

        saveDeworm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveDeworming();
            }
        });
        return view;

    }

    private void saveDeworming() {
        String dewormDate = DewormingDate.getText().toString().trim();
        String dewormdueDate = DewormingDueDate.getText().toString().trim();

        if (!dewormDate.isEmpty() && !dewormdueDate.isEmpty()) {
            DatabaseReference newDewormingRef = databaseReference.push();

            newDewormingRef.child("date").setValue(dewormDate);
            newDewormingRef.child("dueDate").setValue(dewormdueDate);


            DewormingDate.setText("");
            DewormingDueDate.setText("");
        }
    }
}