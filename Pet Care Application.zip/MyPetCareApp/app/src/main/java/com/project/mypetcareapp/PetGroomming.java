package com.project.mypetcareapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;

public class PetGroomming extends AppCompatActivity {
    private LinearLayout linearbath, linearappoint,linearhairloss;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pet_groomming);
        linearappoint = findViewById(R.id.appoint);
        linearappoint.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(PetGroomming.this,Appointments.class);
                startActivity(i);
            }
        });
        linearbath = findViewById(R.id.medibath);
        linearbath.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(PetGroomming.this,MedicatedBath.class);
                startActivity(i);
            }
        });
        linearhairloss = findViewById(R.id.hairloss);
        linearhairloss.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(PetGroomming.this,Doghairloss.class);
                startActivity(i);
            }
        });

    }
}