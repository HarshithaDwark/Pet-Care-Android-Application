package com.project.mypetcareapp;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.Map;

public class PetProfile extends AppCompatActivity {
    private static final int REQUEST_SELECT_PHOTO = 1;
    private ImageView propic;
    private Button sbtn;
    private ImageView ivPhoto;
    private EditText petNameEditText, petAgeEditText, petBreedEditText, petWeightEditText, petGenderEditText;
    private Uri photoUri;
    private DatabaseReference databaseReference;
    private String imageUrl;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pet_profile);
        propic = findViewById(R.id.pro_pic);

        petNameEditText = findViewById(R.id.petname);
        petAgeEditText = findViewById(R.id.petage);
        petBreedEditText = findViewById(R.id.petbreed);
        petWeightEditText = findViewById(R.id.petweight);
        petGenderEditText = findViewById(R.id.petgender);

        Button SelectPhoto = findViewById(R.id.uplodepro);
        SelectPhoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.setType("image/");
                startActivityForResult(intent, REQUEST_SELECT_PHOTO);
            }
        });


        sbtn = findViewById(R.id.savebtn);
        sbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                savePetDetails();
            }
        });
        FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReference("Pets");
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_SELECT_PHOTO && resultCode == RESULT_OK) {
            photoUri = data.getData();
            Bitmap photo = null;
            try {
                photo = BitmapFactory.decodeStream(getContentResolver().openInputStream(photoUri));
            } catch (FileNotFoundException e) {
                throw new RuntimeException(e);
            }
            propic.setImageBitmap(photo);
            Log.d("PET_PROFILE", "Photo URI: " + photoUri.toString());
        }
    }

    private void savePetDetails() {

        String petName = petNameEditText.getText().toString().trim();
        String petAge = petAgeEditText.getText().toString().trim();
        String petBreed = petBreedEditText.getText().toString().trim();
        String petWeight = petWeightEditText.getText().toString().trim();
        String petGender = petGenderEditText.getText().toString().trim();
        if (petName.isEmpty()) {
            Toast.makeText(this, "Please enter pet name.", Toast.LENGTH_SHORT).show();
            return;
        }
        if (petAge.isEmpty()) {
            Toast.makeText(this, "Please enter pet age.", Toast.LENGTH_SHORT).show();
            return;
        }
        if (petBreed.isEmpty()) {
            Toast.makeText(this, "Please enter pet breed.", Toast.LENGTH_SHORT).show();
            return;
        }
        if (petWeight.isEmpty()) {
            Toast.makeText(this, "Please enter pet weight.", Toast.LENGTH_SHORT).show();
            return;
        }
        if (petGender.isEmpty()) {
            Toast.makeText(this, "Please enter pet gender.", Toast.LENGTH_SHORT).show();
            return;
        }
        Log.d("PET_PROFILE", "Save button clicked.");
        if (photoUri != null) {
            String petId = databaseReference.push().getKey();


            uploadImageToFirebaseStorage(petId);
            Pet pet = new Pet(petId, petName, petAge, petBreed, petWeight, petGender, imageUrl);

            databaseReference.child(petId).setValue(pet).addOnCompleteListener(new OnCompleteListener<Void>() {
                @Override
                public void onComplete(@NonNull Task<Void> task) {
                    if (task.isSuccessful()) {
                        Toast.makeText(PetProfile.this, "Pet details saved!", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(PetProfile.this, "Failed to save pet details.", Toast.LENGTH_SHORT).show();
                    }
                }
            });
        } else {
            Toast.makeText(this, "Please select a photo for your pet.", Toast.LENGTH_SHORT).show();
        }
    }

    private void uploadImageToFirebaseStorage(final String petId) {
        FirebaseStorage firebaseStorage = FirebaseStorage.getInstance();
        StorageReference storageReference = firebaseStorage.getReference("pet_images").child(petId);

        storageReference.putFile(photoUri).addOnCompleteListener(new OnCompleteListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<UploadTask.TaskSnapshot> task) {
                if (task.isSuccessful()) {
                    Log.d("PET_PROFILE", "Image upload successful.");

                    storageReference.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                        @Override
                        public void onSuccess(Uri uri) {
                            String imageUrl = uri.toString(); // Fix the variable shadowing
                            savePetDataToDatabase(petId, imageUrl);
                        }
                    });
                } else {
                    Toast.makeText(PetProfile.this, "Image upload failed.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void savePetDataToDatabase(String petId, String imageUrl) {
        String petName = petNameEditText.getText().toString().trim();
        String petAge = petAgeEditText.getText().toString().trim();
        String petBreed = petBreedEditText.getText().toString().trim();
        String petWeight = petWeightEditText.getText().toString().trim();
        String petGender = petGenderEditText.getText().toString().trim();

        Map<String, Object> petData = new HashMap<>();
        petData.put("petName", petName);
        petData.put("petAge", petAge);
        petData.put("petBreed", petBreed);
        petData.put("petWeight", petWeight);
        petData.put("petGender", petGender);
        petData.put("imageUrl", imageUrl);

        databaseReference.child(petId).setValue(petData).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if (task.isSuccessful()) {
                    Toast.makeText(PetProfile.this, "Pet details saved!", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(PetProfile.this, "Failed to save pet details.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}

