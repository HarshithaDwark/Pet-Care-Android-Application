package com.project.mypetcareapp;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Appointments extends AppCompatActivity {
    private EditText editTextAppointmentDetails, editTextAppointmentDate, editTextAppointmentTime;
    private DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_appointments);
        editTextAppointmentDetails = findViewById(R.id.editTextText5);
        editTextAppointmentDate = findViewById(R.id.editTextDate2);
        editTextAppointmentTime = findViewById(R.id.editTextTime);
        Button btnSave = findViewById(R.id.button2);
        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveAppointmentData();
            }
        });
        FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReference("Appointments");
    }
    private void saveAppointmentData() {
        String appointmentDetails = editTextAppointmentDetails.getText().toString().trim();
        String appointmentDate = editTextAppointmentDate.getText().toString().trim();
        String appointmentTime = editTextAppointmentTime.getText().toString().trim();
        if (appointmentDetails.isEmpty() || appointmentDate.isEmpty() || appointmentTime.isEmpty()) {
            Toast.makeText(this, "Please fill in all the fields.", Toast.LENGTH_SHORT).show();
            return;
        }

        String appointmentId = databaseReference.push().getKey();
        AppointmentData appointmentData = new AppointmentData(appointmentDetails, appointmentDate, appointmentTime);

        databaseReference.child(appointmentId).setValue(appointmentData)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        Toast.makeText(Appointments.this, "Appointment data saved successfully.", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(Appointments.this, "Failed to save appointment data.", Toast.LENGTH_SHORT).show();
                    }
                });
    }
}

