package com.project.mypetcareapp;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;

public class PetGuide extends AppCompatActivity {
private LinearLayout linear1, linear2,linear3;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pet_guide);
        linear1 = findViewById(R.id.tp);
        linear1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(PetGuide.this,TickPrev.class);
                startActivity(i);
            }
        });
        linear2 = findViewById(R.id.feed);
        linear2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(PetGuide.this,FeedingGuide.class);
                startActivity(i);
            }
        });
        linear3 = findViewById(R.id.vitamin);
        linear3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(PetGuide.this,vitalvitamins.class);
                startActivity(i);
            }
        });
    }
}