package com.project.mypetcareapp;

public class AppointmentData {
    private String appointmentDetails;
    private String appointmentDate;
    private String appointmentTime;

    public AppointmentData() {
        // Default constructor required for Firebase
    }

    public AppointmentData(String appointmentDetails, String appointmentDate, String appointmentTime) {
        this.appointmentDetails = appointmentDetails;
        this.appointmentDate = appointmentDate;
        this.appointmentTime = appointmentTime;
    }

    public String getAppointmentDetails() {
        return appointmentDetails;
    }

    public void setAppointmentDetails(String appointmentDetails) {
        this.appointmentDetails = appointmentDetails;
    }

    public String getAppointmentDate() {
        return appointmentDate;
    }
    public void setAppointmentDate(String appointmentDate) {
        this.appointmentDate = appointmentDate;
    }

    public String getAppointmentTime() {
        return appointmentTime;
    }

    public void setAppointmentTime(String appointmentTime) {
        this.appointmentTime = appointmentTime;
    }
}


