package com.project.mypetcareapp;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;

import javax.annotation.Nullable;


public class PetGallary extends AppCompatActivity {
private ImageView ivPhoto;
private static final int REQUEST_TAKE_PHOTO = 1, REQUEST_SELECT_PHOTO = 2;
    private StorageReference storageReference;
    private static final String GALLERY_DIRECTORY_NAME = "MyGalleryApp";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pet_gallary);
        ivPhoto = findViewById(R.id.iv_photo);
        FirebaseStorage.getInstance().getReference();

        Button btnTakePhoto = findViewById(R.id.btn_take_photo);
        btnTakePhoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);

                startActivityForResult(intent, REQUEST_TAKE_PHOTO);
            }
        });
        Button btnSelectPhoto = findViewById(R.id.btn_select_photo);
        btnSelectPhoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.setType("image/*");
                startActivityForResult(intent, REQUEST_SELECT_PHOTO);
            }
        });

    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode,@Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_TAKE_PHOTO && resultCode == RESULT_OK) {
            if (data != null) {
                Bitmap photo = (Bitmap) data.getExtras().get("data");
                if (data != null) {
                    ivPhoto.setImageBitmap(photo);
                    uploadImageToFirebase(photo);
                }
            }
                } else if (requestCode == REQUEST_SELECT_PHOTO && resultCode == RESULT_OK) {
            if (data != null && data.getData() != null) {
                Uri photoUri = data.getData();
            try {
                Bitmap photo = BitmapFactory.decodeStream(getContentResolver().openInputStream(photoUri));
                if (photo != null) {
                    ivPhoto.setImageBitmap(photo);
                    uploadImageToFirebase(photo);
                }
                } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        }
        }
    }
    private void uploadImageToFirebase(Bitmap bitmap) {

        String fileName = "image_" + System.currentTimeMillis() + ".jpg";

        StorageReference imageRef = storageReference.child(fileName);


        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos);
        byte[] imageData = baos.toByteArray();

        UploadTask uploadTask = imageRef.putBytes(imageData);

        uploadTask.addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                // Image upload is successful
                Toast.makeText(this, "Image uploaded successfully", Toast.LENGTH_SHORT).show();
            } else {
                // Image upload failed
                Toast.makeText(this, "Failed to upload image", Toast.LENGTH_SHORT).show();
            }
   });
    }
}

