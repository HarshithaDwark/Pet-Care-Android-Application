package com.project.mypetcareapp;

public class Pet {
    private String petId;
    private String petName;
    private String petAge;
    private String petBreed;
    private String petWeight;
    private String petGender;
    private String imageUrl;

    public Pet() {
    }

    public Pet(String petId, String petName, String petAge, String petBreed, String petWeight, String petGender, String imageUrl) {
        this.petId = petId;
        this.petName = petName;
        this.petAge = petAge;
        this.petBreed = petBreed;
        this.petWeight = petWeight;
        this.petGender = petGender;
        this.imageUrl = imageUrl;
    }


    // Getter and setter methods for all fields
    public String getPetId() {
        return petId;
    }

    public void setPetId(String petId) {
        this.petId = petId;
    }

    public String getPetName() {
        return petName;
    }

    public void setPetName(String petName) {
        this.petName = petName;
    }

    public String getPetAge() {
        return petAge;
    }

    public void setPetAge(String petAge) {
        this.petAge = petAge;
    }

    public String getPetBreed() {
        return petBreed;
    }

    public void setPetBreed(String petBreed) {
        this.petBreed = petBreed;
    }

    public String getPetWeight() {
        return petWeight;
    }

    public void setPetWeight(String petWeight) {
        this.petWeight = petWeight;
    }

    public String getPetGender() {
        return petGender;
    }

    public void setPetGender(String petGender) {
        this.petGender = petGender;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    }
