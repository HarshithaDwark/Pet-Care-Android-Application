package com.project.mypetcareapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;

public class PetTraining extends AppCompatActivity {
    private LinearLayout linear1, linear2, linear3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pet_training);
        linear1 = findViewById(R.id.spin);
        linear1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(PetTraining.this, Spin.class);
                startActivity(i);
            }
        });
        linear2 = findViewById(R.id.hoop);
        linear2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(PetTraining.this, HoopJumps.class);
                startActivity(i);
            }
        });
        linear3 = findViewById(R.id.BO);
        linear3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(PetTraining.this, BasicObedience.class);
                startActivity(i);
            }
        });
    }
}