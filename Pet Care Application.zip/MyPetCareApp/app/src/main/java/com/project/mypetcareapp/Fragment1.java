package com.project.mypetcareapp;

import android.annotation.SuppressLint;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;


public class Fragment1 extends Fragment {
    private EditText editTextVaccine, editTextVaccineDate, editVaccineDueDate;
    private DatabaseReference databaseReference;
    private Button buttonSaveVaccine;

    @SuppressLint("MissingInflatedId")
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_1, container, false);
        editTextVaccine = view.findViewById(R.id.editTextText4);
        editTextVaccineDate = view.findViewById(R.id.editTextDate);
        editVaccineDueDate = view.findViewById(R.id.editTextDate1);
        buttonSaveVaccine = view.findViewById(R.id.vaccineSave);

        databaseReference = FirebaseDatabase.getInstance().getReference().child("vaccines");

        buttonSaveVaccine.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveVaccine();
            }
        });
        return view;
    }
    private void saveVaccine() {
        String vaccineName = editTextVaccine.getText().toString().trim();
        String vaccineDate = editTextVaccineDate.getText().toString().trim();
        String dueDate = editVaccineDueDate.getText().toString().trim();

        if (!vaccineName.isEmpty() && !vaccineDate.isEmpty() && !dueDate.isEmpty()) {
            DatabaseReference newVaccineRef = databaseReference.push();
            newVaccineRef.child("name").setValue(vaccineName);
            newVaccineRef.child("date").setValue(vaccineDate);
            newVaccineRef.child("dueDate").setValue(dueDate);

            // Clear input fields after saving
            editTextVaccine.setText("");
            editTextVaccineDate.setText("");
            editVaccineDueDate.setText("");
        }
    }
}
