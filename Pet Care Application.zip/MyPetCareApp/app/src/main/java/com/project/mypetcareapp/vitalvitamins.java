package com.project.mypetcareapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class vitalvitamins extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vitalvitamins);
    }
}